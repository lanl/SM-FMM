cd px_n10_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n20_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n50_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n100_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n200_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n500_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n1000_double_pt
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait