cd px_n10
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n20
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n50
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n100
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n200
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n500
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait

cd px_n1000
./../code/LS-EVPFFT --nthreads 70 &>log&
cd ..

wait