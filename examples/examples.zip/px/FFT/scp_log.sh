scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n10_double_pt/log ./px_n10_double_pt/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n20_double_pt/log ./px_n20_double_pt/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n50_double_pt/log ./px_n50_double_pt/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n100_double_pt/log ./px_n100_double_pt/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n200_double_pt/log ./px_n200_double_pt/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n500_double_pt/log ./px_n500_double_pt/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FFT/px_n1000_double_pt/log ./px_n1000_double_pt/
