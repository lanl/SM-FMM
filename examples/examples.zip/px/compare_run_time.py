import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 14

# FFT
file_names = ['FFT/px_n10/log','FFT/px_n20/log','FFT/px_n50/log','FFT/px_n100/log','FFT/px_n200/log','FFT/px_n500/log','FFT/px_n1000/log']

# Open the file in read mode
conv_time = []
nel = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'avg_conv_time' in line:
            line_list = line.split()
            # print(float(line_list[1]))
            conv_time.append(float(line_list[1]))

        if 'Initializing FFTW on grid' in line:
            line_list = line.split()
            # print(line_list[4][9:-1])
            str_tmp = line_list[4][9:-1]
            str_num = str_tmp.split(',')
            nel.append(np.power(int(str_num[0]),3))

print('FFT')
conv_time_FFT = conv_time
nel_FFT = nel
print(conv_time_FFT)
print(nel)

fig = plt.figure()
ax = fig.add_subplot(111)
# ax.loglog(nel, conv_time, marker='s', linestyle='--', color='k')

# FFT double
# file_names = ['FFT/px_n10_double_pt/log','FFT/px_n20_double_pt/log','FFT/px_n50_double_pt/log','FFT/px_n100_double_pt/log','FFT/px_n200_double_pt/log','FFT/px_n500_double_pt/log','FFT/px_n1000_double_pt/log']
file_names = ['FFT/px_n10_double_pt/log','FFT/px_n20_double_pt/log','FFT/px_n50_double_pt/log','FFT/px_n100_double_pt/log','FFT/px_n200_double_pt/log','FFT/px_n500_double_pt/log','FFT/px_n1000_double_pt/log']

# Open the file in read mode
conv_time = []
nel = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'avg_conv_time' in line:
            line_list = line.split()
            # print(float(line_list[1]))
            conv_time.append(float(line_list[1]))

        if 'Initializing FFTW on grid' in line:
            line_list = line.split()
            # print(line_list[4][9:-1])
            str_tmp = line_list[4][9:-1]
            str_num = str_tmp.split(',')
            nel.append(np.power(int(str_num[0]),3))

print('FFT double pt')
conv_time_FFT_2xpt = conv_time
print(conv_time_FFT_2xpt)
print(nel)

ax.loglog(nel, conv_time, marker='s', linestyle='-', color='k', label='FFT')

# FMM
file_names = ['FMM/px_n10/log','FMM/px_n20/log','FMM/px_n50/log','FMM/px_n100/log','FMM/px_n200/log','FMM/px_n500/log','FMM/px_n1000/log']

# Open the file in read mode
conv_time = []
nel = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'avg_conv_time' in line:
            line_list = line.split()
            # print(float(line_list[1]))
            conv_time.append(float(line_list[1]))

        if 'nel' in line:
            line_list = line.split()
            # print(float(line_list[2]))
            nel.append(int(line_list[3]))

print('FMM')
conv_time_FMM = conv_time
nel_FMM = nel
print(conv_time_FMM)
print(nel)

ax.loglog(nel, conv_time, marker='s', linestyle='-', color='b', label='FMM-FFT')

# nel = np.power(2,range(14,21))
# conv_time = nel*np.log2(nel)*2.0e-8
# 
# ax.loglog(nel, conv_time, linestyle='--', color='r')

# ax.plot(order, np.repeat(conv_time[-1], len(order)))
# ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xlabel('Number of elements', color='k')
ax.set_ylabel('Convolution computation time [s]', color='k')
plt.legend(frameon=False)
plt.savefig("px_run_time.png", dpi = 400, bbox_inches = 'tight')

conv_per_el_FMM = np.array(conv_time_FMM)/np.array(nel_FMM)
conv_time_FFT_2xpt = np.array(conv_time_FFT_2xpt)/np.array(nel_FFT)
print('ratio of FMM to FFT(2 x pt):' + str(conv_per_el_FMM/conv_time_FFT_2xpt))
print('FMM time over elements:' + str(conv_per_el_FMM))
print('FFT time over elements:' + str(conv_time_FFT_2xpt))
print('FFT time over actual elements:' + str(conv_time_FFT_2xpt))