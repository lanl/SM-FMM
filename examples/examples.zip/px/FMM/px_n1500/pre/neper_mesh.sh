~/neper-main/src/build/neper -T -n 1500 -id reg -regularization 1 
~/neper-main/src/build/neper -M n1500-idreg.tess -rcl 0.4 -format vtk -order 1
