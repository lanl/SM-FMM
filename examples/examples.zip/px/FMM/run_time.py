import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

file_names = ['px_n10/log','px_n20/log','px_n50/log','px_n100/log','px_n200/log','px_n500/log','px_n1000/log']

# Open the file in read mode
conv_time = []
nel = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'avg_conv_time' in line:
            line_list = line.split()
            # print(float(line_list[1]))
            conv_time.append(float(line_list[1]))

        if 'nel' in line:
            line_list = line.split()
            # print(float(line_list[2]))
            nel.append(int(line_list[3]))

print(conv_time)
print(nel)



fig = plt.figure()
ax = fig.add_subplot(111)
ax.loglog(nel, conv_time, marker='s', linestyle='-', color='k')
# ax.plot(order, np.repeat(conv_time[-1], len(order)))
# ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xlabel('Number of elements', color='k')
ax.set_ylabel('Time[s]', color='k')
plt.savefig("run_time.png", dpi = 400, bbox_inches = 'tight')

exit()

ax1 = ax.twinx() 

# fig1 = plt.figure()
# ax1 = fig1.add_subplot(111)
ax1.plot(order, str_dif[0:len(order)], marker='s', linestyle='-', color='r')
ax1.plot(order, np.repeat(str_dif[-1], len(order)), linestyle='--', color='r')
ax1.set_ylabel('Strain difference', color='r')
ax1.tick_params(axis='y', labelcolor='r')

plt.savefig("str_dif.png", dpi = 400, bbox_inches = 'tight')