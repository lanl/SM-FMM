cd px_n20/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n200/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n1500/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait
