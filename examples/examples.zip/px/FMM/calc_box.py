import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

ngr = [10,20,50,100,200,500,1000,1500]
nel_arr = []
for gr in ngr:
    nel_arr.append(gr*1300)

nbox = []
grid = []
for nel in nel_arr:
    nbox.append(int((float(nel)/10.0)**0.33333333))
    grid.append(int(nel**0.33333333))

print('number of grains: ' + str(ngr))
print('number of elements: ' + str(nel_arr))
print('number of boxes: ' + str(nbox))
print('grid: ' + str(grid))