cd px_n10/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n50/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n100/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n500/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n1000/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait

cd px_n2000/pre
./neper_mesh.sh &>log&
cd ..
cd ..

wait