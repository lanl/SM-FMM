import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

ngrtot = 2000

randmat = np.random.rand(ngrtot,3)

eul = np.empty([ngrtot,3])
eul[:,0] = randmat[:,0]*360.0
acosEul2 = 2.0*randmat[:,1] - 1.0
eul[:,1] = np.arccos(acosEul2)*180.0/np.pi
eul[:,2] = randmat[:,2]*360.0

np.savetxt("rand_tex.in", eul, fmt='%8.4e')