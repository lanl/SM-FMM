cd px_n100_box10_ord0
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box15_ord0
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box20_ord0
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box25_ord0
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box30_ord0
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box35_ord0
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box10_ord1
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box15_ord1
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box20_ord1
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box25_ord1
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box30_ord1
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box35_ord1
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box10_ord2
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box15_ord2
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box20_ord2
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box25_ord2
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box30_ord2
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box35_ord2
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box10_ord3
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box15_ord3
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box20_ord3
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box25_ord3
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box30_ord3
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box35_ord3
./../../code/FMM --nthreads 70 &>log&
cd ..

wait


cd px_n100_box10_ord4
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box15_ord4
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box20_ord4
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box25_ord4
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box30_ord4
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_box35_ord4
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n100_full
./../../code/FMM --nthreads 70 &>log&
cd ..

wait