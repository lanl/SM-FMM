import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 14

order_arr = [0,1,2,3,4]

file_name = 'log_compare_vtk'
file = open(file_name, 'r')
str_diff = []
# Read each line in the file
for line in file:
    if 'dfield/norm2(field1avg)' in line:
        line_list = line.split()
        str_diff.append(float(line_list[1]))

str_diff = np.reshape(str_diff, (5,6))

for order in order_arr:
    file_names = ['log_files/log_px_n100_box10_ord','log_files/log_px_n100_box15_ord','log_files/log_px_n100_box20_ord',
    'log_files/log_px_n100_box25_ord','log_files/log_px_n100_box30_ord','log_files/log_px_n100_box35_ord']

    nbox = [10,15,20,25,30,35]

    # Open the file in read mode
    conv_time = []
    outgoing_time = []
    incoming_time = []
    near_time = []
    nel = []
    nel_per_box = []
    for file_name in file_names:

        file = open(file_name+str(order), 'r')
        # Read each line in the file
        for line in file:
            # Print each line
            # print(line.strip())
            if 'avg_conv_time' in line:
                line_list = line.split()
                # print(float(line_list[1]))
                conv_time.append(float(line_list[1]))

            if 'avg_outgoing' in line:
                line_list = line.split()
                # print(float(line_list[1]))
                outgoing_time.append(float(line_list[1]))

            if 'avg_incoming' in line:
                line_list = line.split()
                # print(float(line_list[1]))
                incoming_time.append(float(line_list[1]))

            if 'avg_near' in line:
                line_list = line.split()
                # print(float(line_list[1]))
                near_time.append(float(line_list[1]))

            if 'nel' in line:
                line_list = line.split()
                # print(float(line_list[2]))
                nel.append(int(line_list[3]))

    print(conv_time)
    print(nel)
    nel_per_box = np.array(nel)/np.power(nbox,3)
    print(nel_per_box)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    # ax.plot(nel_per_box, conv_time, marker='s', linestyle='-', color='k')
    # ax.set_xlabel('Number of elements per box', color='k')
    ax.plot(nbox, conv_time, marker='s', linestyle='-', color='k', label='Total')
    ax.plot(nbox, near_time, marker='s', linestyle='-', color='r', label='Near')
    ax.plot(nbox, outgoing_time, marker='s', linestyle='-', color='b', label='Outgoing')
    ax.plot(nbox, incoming_time, marker='s', linestyle='-', color='g', label='Incoming')
    ax.set_xlabel('Number of boxes per dimension', color='k')
    ax.set_ylabel('Time [s]', color='k')
    ax1 = ax.twinx() 
    ax1.semilogy(nbox, str_diff[order,:], marker='o', linestyle='--', color='m', label='Realtive strain diff.')
    ax1.set_ylabel('Relative strain difference', color='m')
    ax1.set_ylim(0.005, 0.12)  
    ax1.tick_params(axis='y', labelcolor='m')
    ax.legend(frameon=False)
    ax.set_ylim(0.0, 1.25)
    plt.title('Order '+str(order))
    plt.savefig("px_FMMbx_run_time_ord"+str(order)+".png", dpi = 400, bbox_inches = 'tight')
