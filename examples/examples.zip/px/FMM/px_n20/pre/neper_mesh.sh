~/neper-main/src/build/neper -T -n 20 -id reg -regularization 1 
~/neper-main/src/build/neper -M n20-idreg.tess -rcl 0.4 -format vtk -order 1
