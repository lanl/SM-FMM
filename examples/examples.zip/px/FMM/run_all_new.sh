cd px_n10
./../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n20
./../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n200
./../code/FMM --nthreads 70 &>log&
cd ..

wait

cd px_n1500
./../code/FMM --nthreads 70 &>log&
cd ..

wait
