scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n10/log ./px_n10/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n20/log ./px_n20/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n50/log ./px_n50/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n100/log ./px_n100/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n200/log ./px_n200/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n500/log ./px_n500/
scp -r miroslav@guido.lanl.gov:~/FMM/FMM_FFT_tetrahedral_final/px/FMM/px_n1000/log ./px_n1000/
