cd FMM/vary_box/
./run_all_px_n100_box.sh &>log&
cd ../..
wait

cd FMM/
./run_all.sh &>log&
cd ..
wait

cd FFT/
./run_all_double_pt.sh &>log&
cd ..
wait