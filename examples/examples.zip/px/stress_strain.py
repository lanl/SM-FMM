import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.colors as mcolors
import numpy as np
import os
import re

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 14

# FMM
incplt = 20
pwd = os.getcwd()
fname = pwd + '/FMM/px_n200_pl_avg/averages.out'
data = np.loadtxt(fname, skiprows=1)

Savg_Mandel = data[:,1:7]
Eavg_Mandel = data[:,7:13]

Savg_Mandel_dev = Savg_Mandel
Eavg_Mandel_dev = Eavg_Mandel
svm_FMM = [0.0]
evm_FMM = [0.0]
for i in range(0,len(Savg_Mandel_dev[:,0])):
    shyd = (Savg_Mandel_dev[i,0] + Savg_Mandel_dev[i,1] + Savg_Mandel_dev[i,2])/3.0
    print(shyd)
    Savg_Mandel_dev[i,0] = Savg_Mandel_dev[i,0] - shyd
    Savg_Mandel_dev[i,1] = Savg_Mandel_dev[i,1] - shyd
    Savg_Mandel_dev[i,2] = Savg_Mandel_dev[i,2] - shyd
    svm_FMM.append(np.linalg.norm(Savg_Mandel_dev[i,:])*np.sqrt(3.0/2.0))

    ehyd = (Eavg_Mandel_dev[0,0] + Eavg_Mandel_dev[0,1] + Eavg_Mandel_dev[0,2])/3.0
    Eavg_Mandel_dev[i,0] = Eavg_Mandel_dev[i,0] - ehyd
    Eavg_Mandel_dev[i,1] = Eavg_Mandel_dev[i,1] - ehyd
    Eavg_Mandel_dev[i,2] = Eavg_Mandel_dev[i,2] - ehyd
    evm_FMM.append(np.linalg.norm(Eavg_Mandel_dev[i,:])*np.sqrt(2.0/3.0))

# FFT
fname = pwd + '/FFT/px_n200_double_pt_pl/evpfft_outputs/str_str.out'
data = np.loadtxt(fname, skiprows=1)

Eavg_Voigt = data[:,0:6]
Savg_Voigt = data[:,6:12]

Eavg_Voigt_dev = Eavg_Voigt
Savg_Voigt_dev = Savg_Voigt
svm_FFT = [0.0]
evm_FFT = [0.0]
fact = np.array([1.0,1.0,1.0,2.0,2.0,2.0])
for i in range(0,len(Savg_Voigt[:,0])):
    shyd = (Savg_Voigt_dev[i,0] + Savg_Voigt_dev[i,1] + Savg_Voigt_dev[i,2])/3.0
    print(shyd)
    Savg_Voigt_dev[i,0] = Savg_Voigt_dev[i,0] - shyd
    Savg_Voigt_dev[i,1] = Savg_Voigt_dev[i,1] - shyd
    Savg_Voigt_dev[i,2] = Savg_Voigt_dev[i,2] - shyd
    svm_FFT.append(np.linalg.norm(Savg_Voigt_dev[i,:]*fact)*np.sqrt(3.0/2.0))

    ehyd = (Eavg_Voigt_dev[i,0] + Eavg_Voigt_dev[i,1] + Eavg_Voigt_dev[i,2])/3.0
    Eavg_Voigt_dev[i,0] = Eavg_Voigt_dev[i,0] - ehyd
    Eavg_Voigt_dev[i,1] = Eavg_Voigt_dev[i,1] - ehyd
    Eavg_Voigt_dev[i,2] = Eavg_Voigt_dev[i,2] - ehyd
    evm_FFT.append(np.linalg.norm(Eavg_Voigt_dev[i,:]*fact)*np.sqrt(2.0/3.0))

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(evm_FMM[0:incplt], svm_FMM[0:incplt], color='r', marker='s', linestyle='-', label='FMM-FFT')
ax.plot(evm_FFT[0:incplt], svm_FFT[0:incplt], color='b', marker='o', linestyle='--', label='NP-FFT')

ax.set_xlabel('Equivalent strain', color='k')
ax.set_ylabel('Equivalent (von Mises) stress [MPa]', color='k')
plt.legend(frameon=False)
plt.savefig("px_stress_strain.png", dpi = 400, bbox_inches = 'tight')
plt.close

Eavg_Mandel = np.concatenate((np.zeros((1,6)),Eavg_Mandel))
Savg_Mandel = np.concatenate((np.zeros((1,6)),Savg_Mandel))

Eavg_Voigt = np.concatenate((np.zeros((1,6)),Eavg_Voigt))
Savg_Voigt = np.concatenate((np.zeros((1,6)),Savg_Voigt))

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(Eavg_Mandel[0:incplt,2], Savg_Mandel[0:incplt,2], color='r', marker='s', linestyle='-')
ax.plot(Eavg_Voigt[0:incplt,2], Savg_Voigt[0:incplt,2], color='b', marker='o', linestyle='--')

ax.set_xlabel('Strain 33', color='k')
ax.set_ylabel('Stress 33 [MPa]', color='k')
plt.savefig("px_stress33_strain33.png", dpi = 400, bbox_inches = 'tight')
plt.close

exit()
