rm -r averages
mkdir averages

cp thickness_0p0/E11/averages.out averages/averages_thickness_0p0_E11.out
cp thickness_0p0/E22/averages.out averages/averages_thickness_0p0_E22.out
cp thickness_0p0/E33/averages.out averages/averages_thickness_0p0_E33.out
cp thickness_0p0/E12/averages.out averages/averages_thickness_0p0_E12.out
cp thickness_0p0/E13/averages.out averages/averages_thickness_0p0_E13.out
cp thickness_0p0/E23/averages.out averages/averages_thickness_0p0_E23.out

cp thickness_0p0025/E11/averages.out averages/averages_thickness_0p0025_E11.out
cp thickness_0p0025/E22/averages.out averages/averages_thickness_0p0025_E22.out
cp thickness_0p0025/E33/averages.out averages/averages_thickness_0p0025_E33.out
cp thickness_0p0025/E12/averages.out averages/averages_thickness_0p0025_E12.out
cp thickness_0p0025/E13/averages.out averages/averages_thickness_0p0025_E13.out
cp thickness_0p0025/E23/averages.out averages/averages_thickness_0p0025_E23.out

cp thickness_0p005/E11/averages.out averages/averages_thickness_0p005_E11.out
cp thickness_0p005/E22/averages.out averages/averages_thickness_0p005_E22.out
cp thickness_0p005/E33/averages.out averages/averages_thickness_0p005_E33.out
cp thickness_0p005/E12/averages.out averages/averages_thickness_0p005_E12.out
cp thickness_0p005/E13/averages.out averages/averages_thickness_0p005_E13.out
cp thickness_0p005/E23/averages.out averages/averages_thickness_0p005_E23.out

cp thickness_0p0075/E11/averages.out averages/averages_thickness_0p0075_E11.out
cp thickness_0p0075/E22/averages.out averages/averages_thickness_0p0075_E22.out
cp thickness_0p0075/E33/averages.out averages/averages_thickness_0p0075_E33.out
cp thickness_0p0075/E12/averages.out averages/averages_thickness_0p0075_E12.out
cp thickness_0p0075/E13/averages.out averages/averages_thickness_0p0075_E13.out
cp thickness_0p0075/E23/averages.out averages/averages_thickness_0p0075_E23.out

cp thickness_0p01/E11/averages.out averages/averages_thickness_0p01_E11.out
cp thickness_0p01/E22/averages.out averages/averages_thickness_0p01_E22.out
cp thickness_0p01/E33/averages.out averages/averages_thickness_0p01_E33.out
cp thickness_0p01/E12/averages.out averages/averages_thickness_0p01_E12.out
cp thickness_0p01/E13/averages.out averages/averages_thickness_0p01_E13.out
cp thickness_0p01/E23/averages.out averages/averages_thickness_0p01_E23.out

cp thickness_0p0125/E11/averages.out averages/averages_thickness_0p0125_E11.out
cp thickness_0p0125/E22/averages.out averages/averages_thickness_0p0125_E22.out
cp thickness_0p0125/E33/averages.out averages/averages_thickness_0p0125_E33.out
cp thickness_0p0125/E12/averages.out averages/averages_thickness_0p0125_E12.out
cp thickness_0p0125/E13/averages.out averages/averages_thickness_0p0125_E13.out
cp thickness_0p0125/E23/averages.out averages/averages_thickness_0p0125_E23.out

cp thickness_0p015/E11/averages.out averages/averages_thickness_0p015_E11.out
cp thickness_0p015/E22/averages.out averages/averages_thickness_0p015_E22.out
cp thickness_0p015/E33/averages.out averages/averages_thickness_0p015_E33.out
cp thickness_0p015/E12/averages.out averages/averages_thickness_0p015_E12.out
cp thickness_0p015/E13/averages.out averages/averages_thickness_0p015_E13.out
cp thickness_0p015/E23/averages.out averages/averages_thickness_0p015_E23.out