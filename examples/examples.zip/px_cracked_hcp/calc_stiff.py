import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.colors as mcolors
import numpy as np
import os
import re

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 14

# thickness_arr = np.array([0.0, 0.0025, 0.005, 0.0075, 0.01, 0.0125, 0.015])
thickness_arr = np.array([0.0025, 0.005, 0.0075, 0.01, 0.0125, 0.015])

Cvgtarr = np.zeros((6, 6, len(thickness_arr)), dtype=float)
lamarr = np.zeros(len(thickness_arr), dtype=float)
muarr = np.zeros(len(thickness_arr), dtype=float)

for it, t in enumerate(thickness_arr):

    thick_str = str(thickness_arr[it])
    thick_str = thick_str.replace('.','p')

    Cvgt = np.zeros((6, 6), dtype=float)
    C = np.zeros((6, 6), dtype=float)

    components = ['11','22','33','23','13','12']
    fact_Mandel = [1.0, 1.0, 1.0, np.sqrt(2.0), np.sqrt(2.0), np.sqrt(2.0)]
    fact_Voigt = [1.0, 1.0, 1.0, 2.0, 2.0, 2.0]

    for i, comp in enumerate(components):

        fname = 'averages/averages_thickness_' + thick_str + '_E' + comp + '.out'
        file = open(fname, 'r')
        line = file.readline() # header
        data = file.readline()
        data = data.split()
        data = [float(num) for num in data]
        S = np.array(data[1:7])
        E = np.array(data[7:13])

        Svgt = S/fact_Mandel
        Evgt = E/fact_Mandel*fact_Voigt
            
        Cvgt[:,i] = Svgt/Evgt[i]
        C[:,i] = S/E[i]

    Cvgtarr[:,:,it] = Cvgt
    # print(Cvgtarr[1,1,it])
    np.set_printoptions(precision=3, linewidth=150)
    print(Cvgt)

    mu = (Cvgt[3,3] + Cvgt[4,4] + Cvgt[5,5])/3.0
    Cvgt33 = Cvgt[0:3,0:3]
    Cvgt33[0,0] = Cvgt33[0,0] - mu*2.0
    Cvgt33[1,1] = Cvgt33[1,1] - mu*2.0
    Cvgt33[2,2] = Cvgt33[2,2] - mu*2.0
    lam = sum(sum(Cvgt33))/9.0

    lamarr[it] = lam
    muarr[it] = mu

thickness_arr_rel = thickness_arr*np.power(1.0/50,1.0/3.0)

# print(Cvgt)
# print(C)
# print(C/Cvgt)
print(Cvgtarr[1,1,0])
print(Cvgtarr[1,1,1])

kappaarr = lamarr + 2.0/3.0*muarr
print(kappaarr)
print(lamarr)
print(muarr)

norm = mcolors.Normalize(vmin=0, vmax=5)
cmap = plt.cm.jet
mapper = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
colors = mapper.to_rgba(data)

for i in range(0,6) :
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(thickness_arr_rel, Cvgtarr[i,i,:], color=mapper.to_rgba(i), marker='s')

    # ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
    ax.set_xlabel('Crack thickness / edge length', color='k')
    ax.set_ylabel('Stiffness', color='k')
    plt.savefig("pxc_stiff_vs_thick"+str(i)+".png", dpi = 400, bbox_inches = 'tight')
    plt.close

# isotropic
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(thickness_arr_rel, kappaarr, color='k', marker='s')

ax.set_xlabel('Crack thickness / edge length', color='k')
ax.set_ylabel('Effective bulk modulus [MPa]', color='k')

ax1 = ax.twinx() 
ax1.semilogy(thickness_arr_rel, muarr, marker='o', linestyle='--', color='r')
ax1.set_ylabel('Effective shear modulus [MPa]', color='r')
ax1.tick_params(axis='y', labelcolor='r')

plt.savefig("pxc_iso_stiff_vs_thick.png", dpi = 400, bbox_inches = 'tight')
plt.close

exit()
