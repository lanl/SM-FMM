# ------------------------------------------------------------------------------
#
#  Gmsh Python tutorial 1
#
#  Geometry basics, elementary entities, physical groups
#
# ------------------------------------------------------------------------------

# The Python API is entirely defined in the `gmsh.py' module (which contains the
# full documentation of all the functions in the API):
import gmsh
import sys
import pprint
import numpy as np

# note: the input .geo file should not be created using the regularization in neper (causes issues in adjecancy)
print("note: the input .geo file should not be created using the regularization in neper (causes issues in adjecancy)")

meshSizeDefault = 0.04
meshSizeCrack = 0.02
randGr = 0
ngr = 50
# grain_tag = 2
# surf_in_grain = 2
lgr = np.power(1.0/float(ngr), 1.0/3.0) # grain dimension
thicknessCrack = lgr*0.005 # 0.005 0.03, 0.02, 0.01
# volumeCrack = thicknessCrack # area of cube face is 1, so this is max crack volume
volumeCrack = thicknessCrack*lgr*lgr*2.0 # 
ncrack = 20

print('grain dimension ' + str(lgr))
print('crack thickness ' + str(thicknessCrack))

# grain_tag_crack = [5,0,0,2,7,8,6,8,2,4] 
# surf_in_grain_crack = [0,2,4,1,0,2,5,3,7,0]
aspect_crack = 0.005 # 0.01 0.035, 0.02, 0.02

# Before using any functions in the Python API, Gmsh must be initialized:
gmsh.initialize()

if len(sys.argv) > 1 and sys.argv[1][0] != '-':
    # If an argument is provided, handle it as a file that Gmsh can read, e.g. a
    # mesh file in the MSH format (`python x1.py file.msh')
    gmsh.open(sys.argv[1])
else:
    # Otherwise, create and mesh a simple geometry
    sys.exit("Mesh not provided")

# Print the model name and dimension:
print('Model ' + gmsh.model.getCurrent() + ' (' +
      str(gmsh.model.getDimension()) + 'D)')

gmsh.option.setNumber("Geometry.AutoCoherence", 2)

gmsh.model.geo.synchronize()

# add a new occ model where we will place occ objects
gmsh_model_str = gmsh.model.getCurrent()
gmsh.model.add('occ_model')
gmsh.model.setCurrent(gmsh_model_str)

# get point entities in the loaded model and copy them to occ model as occ objects
shift = 0 # shift the tags
eps = 1.0e-3
points = gmsh.model.getEntitiesInBoundingBox(- eps, -eps, -eps, 1 + eps,
                                            1 + eps, 1 + eps, 0)

for point in points:
    xyz = gmsh.model.getValue(point[0], point[1], [])
    gmsh.model.setCurrent('occ_model')
    gmsh.model.occ.addPoint(xyz[0], xyz[1], xyz[2], meshSize=meshSizeDefault, tag=point[1] + shift)
    gmsh.model.setCurrent(gmsh_model_str)
    # print(point[0])
    # print(xyz)

# get line entities in the loaded model and copy them to occ model as occ objects
lines = gmsh.model.getEntitiesInBoundingBox(- eps, -eps, -eps, 1 + eps,
                                            1 + eps, 1 + eps, 1)

# print(lines)
for line in lines:
    tag_up, tag_down = gmsh.model.getAdjacencies(line[0], line[1])
    gmsh.model.setCurrent('occ_model')
    gmsh.model.occ.addLine(tag_down[0] + shift, tag_down[1] + shift, tag=line[1] + shift)
    gmsh.model.setCurrent(gmsh_model_str)

# get surface entities in the loaded model and copy them to occ model as occ objects
surfaces = gmsh.model.getEntitiesInBoundingBox(- eps, -eps, -eps, 1 + eps,
                                            1 + eps, 1 + eps, 2)

# print(surfaces)
for surface in surfaces:
    tag_up, tag_down = gmsh.model.getAdjacencies(surface[0], surface[1])
    # print(surface[1])
    # print(tag_down)
    gmsh.model.setCurrent('occ_model')
    gmsh.model.occ.addWire (tag_down + shift, tag=surface[1] + shift, checkClosed = True)
    gmsh.model.setCurrent(gmsh_model_str)
    # gmsh.model.occ.addPlaneSurface ([1000+surface[1]], tag=surface[1])

gmsh.model.setCurrent('occ_model')
for surface in surfaces:
    # print(surface[1])
    gmsh.model.occ.addSurfaceFilling (surface[1] + shift, tag=surface[1] + shift)
gmsh.model.setCurrent(gmsh_model_str)

# get volume entities in the loaded model and copy them to occ model as occ objects
volumes = gmsh.model.getEntitiesInBoundingBox(- eps, -eps, -eps, 1 + eps,
                                            1 + eps, 1 + eps, 3)
for volume in volumes:
    tag_up, tag_down = gmsh.model.getAdjacencies(volume[0], volume[1])
    # print(volume[1])
    # print(tag_down)
    gmsh.model.setCurrent('occ_model')
    gmsh.model.occ.addSurfaceLoop (tag_down + shift, tag=volume[1] + shift, sewing = True)
    gmsh.model.setCurrent(gmsh_model_str)

ngr = len(volumes)

gmsh.model.setCurrent('occ_model')
for volume in volumes:
    # print(volume[1])
    gmsh.model.occ.addVolume ([volume[1] + shift], tag=volume[1] + shift)

# make a cut in one grain
# s = []
# s.append((2, gmsh.model.occ.addRectangle(0.0, 0.0, 0.5, 1.0, 1.0)))  # cutting plane

gmsh.model.geo.synchronize()
gmsh.model.occ.synchronize()

cracked_gr_surf = []
for i in range(len(volumes)):
    cracked_gr_surf.append([])

if (randGr == 0):
    grain_tag_crack = np.loadtxt("grain_tag_arr.out", delimiter=",", dtype=int)
    surf_in_grain_crack = np.loadtxt("surf_in_grain_arr.out", delimiter=",", dtype=int)
    ncrack = len(grain_tag_crack)
    print(ncrack)

sarr = []
grain_tag_arr = []
surf_in_grain_arr = []
surfaces_cracked = np.zeros(len(surfaces),dtype = 'int')
for icrack in range(ncrack): # loop over cracks
    print('icrack ' + str(icrack))

    if (randGr == 1):
        grain_tag = np.random.randint(0, ngr) # randomly pick grain tag
        grain_tag_arr.append(grain_tag)
    elif (randGr == 0):
        grain_tag = grain_tag_crack[icrack]
    print('  grain_tag ' + str(grain_tag))
    grain = volumes[grain_tag]
    print('  grain ' + str(grain))
    if gmsh.model.occ.getMass(grain[0], grain[1]) > volumeCrack: # if this is not a crack
    # if gmsh.model.occ.getMass(grain[0], grain[1]) > volumeCrack and len(cracked_gr_surf[grain_tag]) == 0: # if this is not a crack
        print('    volume above threshold')
        tag_up, tag_down = gmsh.model.getAdjacencies(grain[0], grain[1])

        if (randGr == 1):
            surf_in_grain = np.random.randint(0, len(tag_down))
            surf_in_grain_arr.append(surf_in_grain)
        elif (randGr == 0):
            surf_in_grain = surf_in_grain_crack[icrack]

        # print(tag_down[surf_in_grain])
        flag = False
        if surf_in_grain not in cracked_gr_surf[grain_tag]:

            cracked_gr_surf[grain_tag].append(surf_in_grain)
            print('    surf_in_grain ' + str(surf_in_grain))
            surf_tag = tag_down[surf_in_grain] - 1
            if (surfaces_cracked[surf_tag] == 0):
                surfaces_cracked[surf_tag] = 1
                surf = surfaces[surf_tag]
                xc_surf = gmsh.model.occ.getCenterOfMass(surf[0],surf[1])
                print('    xc_surf ' + str(xc_surf))
                if (abs(xc_surf[0])>1.0e-3 and abs(xc_surf[1])>1.0e-3 and abs(xc_surf[2])>1.0e-3 and 
                    abs(xc_surf[0]-1.0)>1.0e-3 and abs(xc_surf[1]-1.0)>1.0e-3 and abs(xc_surf[2]-1.0)>1.0e-3):
                    surf_cp = gmsh.model.occ.copy([surf])
                    surf_cp = surf_cp[0]
                    xc_grain = gmsh.model.occ.getCenterOfMass(grain[0],grain[1])
                    xc_surf = gmsh.model.occ.getCenterOfMass(surf_cp[0],surf_cp[1])
                    # print(gmsh.model.occ.getCenterOfMass(grain[0],grain[1]))
                    # print(gmsh.model.occ.getCenterOfMass(surf_cp[0],surf_cp[1]))
            
                    dxc = np.add(- np.array(xc_surf),np.array(xc_grain))
                    # print(dx)
                    vec = dxc/np.linalg.norm(dxc)
                    normal = np.array(gmsh.model.getNormal(surf[1], [0.5,0.5]))
                    print('      vec ' + str(vec))
                    print('      normal ' + str(normal))
                    if (np.dot(normal,vec) < 0.0):
                        normal = - normal
                    gmsh.model.occ.translate([surf_cp], normal[0]*thicknessCrack, normal[1]*thicknessCrack, normal[2]*thicknessCrack)
                    gmsh.model.occ.dilate([surf_cp], xc_surf[0], xc_surf[1], xc_surf[2], 2.0, 2.0, 2.0)
                    
                    v = [grain]
                    s = [surf_cp]
                    sarr.append(s)
            
                    gmsh.model.occ.fragment(v, s, tag = -1, removeObject = False , removeTool = True) # make the cut
                    gmsh.model.occ.remove(gmsh.model.occ.getEntities(2), True)
            
                    # gmsh.model.occ.synchronize()
                    # gmsh.model.geo.synchronize()
                    # gmsh.model.occ.removeAllDuplicates()
            
                    print('  grain ' + str(grain))

# print(cracked_gr_surf)

if (randGr == 1):
    np.savetxt('grain_tag_arr.out', grain_tag_arr, delimiter=',', fmt='%i')
    np.savetxt('surf_in_grain_arr.out', surf_in_grain_arr, delimiter=',', fmt='%i')

# gmsh.model.occ.synchronize()
# gmsh.model.geo.synchronize()
# gmsh.fltk.run()
# sys.exit()

# gmsh.model.occ.fragment(v, s, tag = -1, removeObject = True , removeTool = True) # make the cut
gmsh.model.occ.remove(gmsh.model.occ.getEntities(2), True)
# # gmsh.model.occ.remove(s, True)
gmsh.model.occ.removeAllDuplicates()
# gmsh.model.occ.healShapes()

# very important, synchronize will make gmsh objects from occ objects (manual)
gmsh.model.occ.synchronize()
gmsh.model.geo.synchronize()

# reset the mesh size for all points (new are included)
points = gmsh.model.getEntities(0)
for point in points:
    gmsh.model.occ.mesh.setSize([point],meshSizeDefault)

volumes = gmsh.model.getEntities(3)

# # set mesh sizes around cracks
# # Mesh size definition:
# if '-clscale' in sys.argv:
#     index = sys.argv.index('-clscale')
#     clscale = float(sys.argv[index + 1])
#     gmsh.option.setNumber("Mesh.MeshSizeFactor", clscale)

# for volume in volumes:
#     print('volume ' + str(gmsh.model.occ.getMass(volume[0], volume[1])))
#     mat_inertia = gmsh.model.occ.getMatrixOfInertia (volume[0], volume[1])
#     mat_inertia = np.array(mat_inertia)
#     mat_inertia = np.reshape(mat_inertia, (3,3))
#     print('inertia ' + str(mat_inertia))
#     eigenvalues, eigenvectors = np.linalg.eig(mat_inertia)
#     print(eigenvalues)
#     sys.exit
#     if gmsh.model.occ.getMass(volume[0], volume[1]) < volumeCrack:
#         tag_up, tag_surf_arr = gmsh.model.getAdjacencies(volume[0], volume[1])
#         ic = 0
#         for tag_surf in tag_surf_arr:
#             tag_up, tag_line_arr = gmsh.model.getAdjacencies(2, tag_surf)
#             for tag_line in tag_line_arr:
#                 tag_up, tag_pt_arr = gmsh.model.getAdjacencies(1, tag_line)
#                 for tag_pt in tag_pt_arr:
#                     # print(tag_pt)
#                     gmsh.model.occ.mesh.setSize([(0,tag_pt)],meshSizeCrack)

volumes_crack =[]
for volume in volumes:
    print('volume ' + str(gmsh.model.occ.getMass(volume[0], volume[1])))
    sys.exit
    tag_up, tag_surf_arr = gmsh.model.getAdjacencies(volume[0], volume[1])
    ic = 0
    tag_pt_in_vol = []
    xc = gmsh.model.occ.getCenterOfMass(volume[0],volume[1])
    xc = np.array(xc)
    dxdx = np.zeros((3,3))
    for tag_surf in tag_surf_arr:
        tag_up, tag_line_arr = gmsh.model.getAdjacencies(2, tag_surf)
        for tag_line in tag_line_arr:
            tag_up, tag_pt_arr = gmsh.model.getAdjacencies(1, tag_line)
            for tag_pt in tag_pt_arr:
                # print(tag_pt)
                xpt = gmsh.model.getValue(0, tag_pt, [])
                xpt = np.array(xpt)
                dx = xpt - xc
                dxdx = dxdx + np.outer(dx,dx)
                tag_pt_in_vol.append(tag_pt)

    dxdx = dxdx/len(tag_pt_in_vol)
    # print(dxdx)
    eigenvalues, eigenvectors = np.linalg.eig(dxdx)
    # print(eigenvalues)
    if np.min(eigenvalues)/np.max(eigenvalues) < aspect_crack:
        # print(np.min(eigenvalues)/np.max(eigenvalues))
        volumes_crack.append(volume)
        for tag_pt in tag_pt_in_vol:

            gmsh.model.occ.mesh.setSize([(0,tag_pt)],meshSizeCrack)

gmsh.model.occ.synchronize()
gmsh.model.geo.synchronize()

# create physical groups from volumes, so that we get element ids on output
ic = 0
tag_crack = []
for volume in volumes:
    print(volume[1])
    if volume not in volumes_crack:
        ic = ic + 1
        # gmsh.model.addPhysicalGroup(3, [volume[1]], volume[1])
        gmsh.model.addPhysicalGroup(3, [volume[1]], ic)
    else:
        tag_crack.append(volume[1])

ic = ic + 1
gmsh.model.addPhysicalGroup(3, tag_crack, ic)

# remove the old loaded model
gmsh.model.setCurrent(gmsh_model_str)
ents = gmsh.model.getEntitiesInBoundingBox(- eps, -eps, -eps, 1 + eps,
                                            1 + eps, 1 + eps)

gmsh.model.geo.remove(ents)
gmsh.model.removePhysicalGroups()
gmsh.model.remove

# remove the old loaded model
gmsh.model.setCurrent('occ_model')
gmsh.model.geo.synchronize()
gmsh.model.occ.synchronize()

# gmsh.option.setNumber("Mesh.Algorithm", 6)
# gmsh.option.setNumber("Mesh.Algorithm3D", 3)
# gmsh.option.setNumber("Mesh.AnisoMax", 10)
# gmsh.option.setNumber("Mesh.OptimizeNetgen", 1)
# gmsh.option.setNumber("Mesh.Smoothing", 50)
# gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary",2)
# gmsh.option.setNumber("Mesh.MeshSizeFromCurvature",1)
# gmsh.option.setNumber("Mesh.QualityType",3)
# gmsh.option.setNumber("Mesh.HighOrderOptimize",1)
# gmsh.option.setNumber("Mesh.OptimizeThreshold",0.5)
# gmsh.option.setNumber("Mesh.SmoothNormals",1)
gmsh.model.mesh.generate(3)

if '-name' in sys.argv:
    index = sys.argv.index('-name')
    fname = sys.argv[index + 1]
else:
    fname = 'mesh.vtk'

gmsh.write(fname)

# # Launch the GUI to see the model:
# if '-nopopup' not in sys.argv:
#     gmsh.fltk.run()

sys.exit(0)
