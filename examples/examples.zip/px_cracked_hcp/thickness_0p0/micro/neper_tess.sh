/Users/miroslavzecevic/projects/FMM/simulations/nepper/neper-main/src/build/neper -T -n 50 -morpho centroidal -id no-reg -morphooptialgo lloyd -regularization 0 -format geo
# /Users/miroslavzecevic/projects/FMM/simulations/nepper/neper-main/src/build/neper -T -n 50 -morpho gg -id no-reg -morphooptistop iter=10000 -regularization 0 -format geo
# /Users/miroslavzecevic/projects/FMM/simulations/nepper/neper-main/src/build/neper -T -n 50 -id no-reg -regularization 0 -format geo
