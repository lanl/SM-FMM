cd E11
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd E22
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd E33
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd E12
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd E13
./../../code/FMM --nthreads 70 &>log&
cd ..

wait

cd E23
./../../code/FMM --nthreads 70 &>log&
cd ..

wait