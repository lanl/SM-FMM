cd thickness_0p0025/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..

cd thickness_0p005/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..

cd thickness_0p0075/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..

cd thickness_0p01/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..

cd thickness_0p0125/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..

cd thickness_0p015/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..

cd thickness_0p0/micro
python mesh_nepper_rand_cracks.py n50-idno-reg.geo &>log&
wait
cd ../..
