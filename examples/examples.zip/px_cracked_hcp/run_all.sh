cd thickness_0p0025
./run_all.sh &>log&
wait
cd ..

cd thickness_0p005
./run_all.sh &>log&
wait
cd ..

cd thickness_0p0075
./run_all.sh &>log&
wait
cd ..

cd thickness_0p01
./run_all.sh &>log&
wait
cd ..

cd thickness_0p0125
./run_all.sh &>log&
wait
cd ..

cd thickness_0p015
./run_all.sh &>log&
wait
cd ..

cd thickness_0p0
./run_all.sh &>log&
wait
cd ..
