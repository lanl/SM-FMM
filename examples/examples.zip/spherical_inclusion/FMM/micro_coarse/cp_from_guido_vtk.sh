scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order0/output.vtk ./order0/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order1/output.vtk ./order1/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order2/output.vtk ./order2/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order3/output.vtk ./order3/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order4/output.vtk ./order4/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/full/output.vtk ./full/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/full/output_analytical.vtk ./full/