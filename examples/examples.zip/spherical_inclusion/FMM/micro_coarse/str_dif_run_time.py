import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

file_names = ['order0/log','order1/log','order2/log','order3/log','order4/log','full/log']
order = [0,1,2,3,4]

# Open the file in read mode
conv_time = []
str_dif = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'avg_conv_time' in line:
            line_list = line.split()
            # print(float(line_list[1]))
            conv_time.append(float(line_list[1]))

        if 'strain difference' in line:
            line_list = line.split()
            # print(float(line_list[2]))
            str_dif.append(float(line_list[2]))

print(conv_time[0:len(order)-1])

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(order, conv_time[0:len(order)], marker='s', linestyle='-', color='k')
# ax.plot(order, np.repeat(conv_time[-1], len(order)))
ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xlabel('Order', color='k')
ax.set_ylabel('Time[s]', color='k')
# plt.savefig("run_time.png", dpi = 400, bbox_inches = 'tight')

ax1 = ax.twinx() 

# fig1 = plt.figure()
# ax1 = fig1.add_subplot(111)
ax1.plot(order, str_dif[0:len(order)], marker='s', linestyle='-', color='r')
ax1.plot(order, np.repeat(str_dif[-1], len(order)), linestyle='--', color='r')
ax1.set_ylabel('Strain difference', color='r')
ax1.tick_params(axis='y', labelcolor='r')

plt.savefig("sph_run_time_str_dif.png", dpi = 400, bbox_inches = 'tight')

plt.close()

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(order, str_dif[0:len(order)], marker='s', linestyle='-', color='k')
ax.plot(order, np.repeat(str_dif[-1], len(order)), linestyle='--', color='k')
ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xlabel('Order', color='k')
ax.set_ylabel('Strain difference', color='k')
plt.savefig("sph_str_dif.png", dpi = 400, bbox_inches = 'tight')

plt.close()
