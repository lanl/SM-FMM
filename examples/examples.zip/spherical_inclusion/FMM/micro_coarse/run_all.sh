cd full
./../../code/FMM --nthreads 1 &>log&
cd ..

wait

cd order0
./../../code/FMM --nthreads 1 &>log&
cd ..

wait

cd order1
./../../code/FMM --nthreads 1 &>log&
cd ..

wait

cd order2
./../../code/FMM --nthreads 1 &>log&
cd ..

wait

cd order3
./../../code/FMM --nthreads 1 &>log&
cd ..

wait

cd order4
./../../code/FMM --nthreads 1 &>log&
cd ..