scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order0/log ./order0/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order1/log ./order1/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order2/log ./order2/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order3/log ./order3/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/order4/log ./order4/
scp -r miroslav@guido.lanl.gov:~/FMM/load_tetra/spherical_inclusion/new/FMM/micro_coarse/full/log ./full/