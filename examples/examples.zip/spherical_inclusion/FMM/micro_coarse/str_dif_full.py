import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 14

file_names = ['log_comp_full_order0','log_comp_full_order1','log_comp_full_order2','log_comp_full_order3','log_comp_full_order4']
order = [0,1,2,3,4]

# Open the file in read mode
str_dif_full = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'dfield' in line:
            line_list = line.split()
            # print(float(line_list[1]))
            str_dif_full.append(float(line_list[1]))
            break

file_names = ['order0/log','order1/log','order2/log','order3/log','order4/log','full/log']
order = [0,1,2,3,4]

# Open the file in read mode
str_dif_anal = []
for file_name in file_names:

    file = open(file_name, 'r')
    # Read each line in the file
    for line in file:
        if 'strain difference' in line:
            line_list = line.split()
            # print(float(line_list[2]))
            str_dif_anal.append(float(line_list[2]))

fig = plt.figure()
ax = fig.add_subplot(111)
# ax.plot(order, str_dif_full[0:len(order)], marker='s', linestyle='-', color='k')
# ax.plot(order, str_dif_anal[0:len(order)], marker='s', linestyle='-', color='r')
# ax.plot(order, np.repeat(str_dif_anal[-1], len(order)), linestyle='--', color='r')
ax.semilogy(order, str_dif_full[0:len(order)], marker='s', linestyle='-', color='k',label='difference w.r.t. direct convolution')
ax.semilogy(order, str_dif_anal[0:len(order)], marker='s', linestyle='-', color='r',label='difference w.r.t. analytical sol.')
ax.semilogy(order, np.repeat(str_dif_anal[-1], len(order)), linestyle='--', color='r')
ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xlabel('Order', color='k')
ax.set_ylabel('Strain difference', color='k')
plt.legend(frameon=False)

# plt.text(
#     x=order[1]+0.5,
#     y=str_dif_anal[-1],
#     color='red',  # Text color
#     s="direct convolution w.r.t. analytical",
# )
plt.annotate(
    "direct convolution w.r.t. analytical sol.",
    color='red',  # Text color
    xy=(order[1]+0.25, str_dif_anal[-1]),  # Coordinates of the arrow head
    xytext=(order[0], str_dif_anal[-1]*1.5),  # Coordinates of the arrow tail
    arrowprops=dict(facecolor='red', edgecolor='red', arrowstyle='->'),
)
plt.savefig("sph_str_dif.png", dpi = 400, bbox_inches = 'tight')

plt.close()
