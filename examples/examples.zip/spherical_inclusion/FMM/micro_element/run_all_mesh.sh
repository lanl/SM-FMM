cd micro_elsz_0p02
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p03
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p04
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p05
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p06
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p07
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p08
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p09
python inclusion.py -nopopup
cd ..

wait

cd micro_elsz_0p1
python inclusion.py -nopopup
cd ..