import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

elsz = np.array([0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1])

nel = np.round(np.power(elsz,-3)*5)
nbx = np.round(np.power((nel/10.0),0.33333333))
ngrid = np.round(np.power(nel,0.33333333))
print(nel)
print(ngrid)
print(nbx)

