cd spherical_inclusion/FMM/micro_coarse/
python str_dif_full.py
cd ../../..
wait

cd spherical_inclusion/FMM/micro_element/
python str_dif_el.py
cd ../../..
wait

cd px/FMM/vary_box/
python run_time.py
cd ../../..
wait

cd px/
python compare_run_time.py
cd ..
wait

cd px/
python stress_strain.py
cd ..
wait

cd px_cracked/
python calc_stiff.py
cd ..
wait
