# ------------------------------------------------------------------------------
#
#  Gmsh Python tutorial 18
#
#  Periodic meshes
#
# ------------------------------------------------------------------------------

# Periodic meshing constraints can be imposed on surfaces and curves.

import gmsh
import math
import os
import sys

gmsh.initialize()

gmsh.model.add("sphere")

# Let's use the OpenCASCADE geometry kernel to build two geometries.

# The first geometry is very simple: a unit cube with a non-uniform mesh size
# constraint (set on purpose to be able to verify visually that the periodicity
# constraint works!):

gmsh.model.occ.addBox(0, 0, 0, 1, 1, 1, 1) # dim 3, tag 1

x = 0.5
y = 0.5
z = 0.5
gmsh.model.occ.addSphere(x, y, z, 0.25, 2) # dim 3, tag 2
gmsh.model.occ.synchronize()

ov, ovv = gmsh.model.occ.fragment([(3, 1)], [(3, 2)]) # [dim=3, tag]

print("fragment produced volumes:")
for e in ov:
    print(e)

gmsh.model.occ.synchronize()

gmsh.model.addPhysicalGroup(3, [2], 2)
gmsh.model.addPhysicalGroup(3, [ov[-1][1]], 3)

gmsh.model.mesh.setSize(gmsh.model.getEntities(0), 0.015)
gmsh.option.setNumber("Mesh.MeshSizeMax", 0.015)

# lcar1 = .05
# lcar2 = .00005
# lcar3 = .2
# 
# # Assign a mesh size to all the points:
# gmsh.model.mesh.setSize(gmsh.model.getEntities(0), lcar1)
# 
# # Override this constraint on the points of the sphere:
# gmsh.model.mesh.setSize(gmsh.model.getBoundary([(3,2)], False, False, True),
#                         lcar2)
# 
# # # Select the corner point by searching for it geometrically:
# # eps = 1e-3
# # ov = gmsh.model.getEntitiesInBoundingBox(1.0 - eps, 1.0 - eps, 1.0 - eps,
# #                                          1.0 + eps, 1.0 + eps, 1.0 + eps, 0)
# # gmsh.model.mesh.setSize(ov, lcar2)
# 
# gmsh.model.mesh.setSize(gmsh.model.getBoundary([(3,3)], False, False, True),
#                         lcar3)

# gmsh.option.setNumber("Mesh.MeshSizeFactor", 0.1)

gmsh.model.mesh.generate(3)
# gmsh.write("inclusion.msh")

fname = 'inclusion.vtk'
gmsh.write(fname)

# Launch the GUI to see the results:
if '-nopopup' not in sys.argv:
    gmsh.fltk.run()

gmsh.clear()

gmsh.finalize()

sys.exit(0)
