cd micro_elsz_0p015
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p02
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p03
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p04
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p05
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p06
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p07
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p08
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p09
./../../code/FMM --nthreads 100 &>log&
cd ..

wait

cd micro_elsz_0p1
./../../code/FMM --nthreads 100 &>log&
cd ..