import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import os
import re

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 14

file_names = ['micro_elsz_0p015','micro_elsz_0p02','micro_elsz_0p03','micro_elsz_0p04','micro_elsz_0p05','micro_elsz_0p06','micro_elsz_0p07','micro_elsz_0p08','micro_elsz_0p09','micro_elsz_0p1']
el_sz = [0.015, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1]
el_sz = np.array(el_sz)

# Open the file in read mode
str_dif = []
nel =[]
for file_name in file_names:

    print(file_name)
    file = open(file_name + '/log', 'r')
    # Read each line in the file
    for line in file:
        # Print each line
        # print(line.strip())
        if 'strain difference' in line:
            line_list = line.split()
            print(float(line_list[2]))
            str_dif.append(float(line_list[2]))

        if 'nel' in line:
            line_list = line.split()
            # print(int(line_list[3]))
            nel.append(int(line_list[3]))

fig = plt.figure()
ax = fig.add_subplot(111)
# ax.loglog(nel, str_dif, marker='s', linestyle='-', color='k')
ax.loglog(el_sz, str_dif, marker='s', linestyle='-', color='k')
ax.loglog(el_sz, np.power(el_sz/el_sz[-1],2)*str_dif[-1], linestyle='--', color='k')
# ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
ax.set_xlabel('Element size', color='k')
ax.set_ylabel('Strain difference', color='k')

# plt.ylim(0.0005, 0.005)

plt.savefig("sph_str_dif_nel.png", dpi = 400, bbox_inches = 'tight')

plt.close()
